import React, { useState } from 'react';
import './style.css';

function App() {
  const [pokemonName, setPokemonName] = useState('');
  const [pokemon, setPokemon] = useState(null);
  const [error, setError] = useState('');

  function loadAPI(name) {
    let url = `https://pokeapi.co/api/v2/pokemon/${name.toLowerCase()}`;
    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error('Pokémon não encontrado');
        }
        return response.json();
      })
      .then(res => {
        setPokemon(res);
        setError('');
      })
      .catch(err => {
        setPokemon(null);
        setError(err.message);
      });
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (pokemonName.trim() !== '') {
      loadAPI(pokemonName);
    }
  }

  return (
    <div className='container'>
      <header>
        <strong>Pokemon API</strong>
      </header>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Digite o nome do Pokémon"
          value={pokemonName}
          onChange={(e) => setPokemonName(e.target.value)}
        />
        <button type="submit">Buscar</button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {pokemon && (
        <div>
          <img src={pokemon.sprites?.front_default} alt={pokemon.name} />
          <div>Nome: {pokemon.name}</div>
          <div>N° {pokemon.id}</div>
          <div>Peso: {pokemon.weight / 10} kg</div>
          <div>Altura: {pokemon.height / 10} m</div>
          <div>Tipo: {pokemon.types.map(t => t.type.name).join(', ')}</div>
          <div>Habilidades: {pokemon.abilities.map(a => a.ability.name).join(', ')}</div>
        </div>
      )}
    </div>
  );
}

export default App;
